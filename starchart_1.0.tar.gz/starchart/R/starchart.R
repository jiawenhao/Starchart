starchart <-
function(x, ...) {
    UseMethod("starchart")
}
